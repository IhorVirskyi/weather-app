import { Component, OnInit } from '@angular/core';
import { WeatherService } from "../services/weather.service";
import {Weather, WeatherInfo} from "../interfaces/weather";
import {Observable} from "rxjs";

@Component({
  selector: 'app-weather-view',
  templateUrl: './weather-view.component.html',
  styleUrls: ['./weather-view.component.scss']
})
export class WeatherViewComponent implements OnInit {
  // temperature: number = 0;
  // temp_feel: number = 0;
  // humidity: number = 0;
  // wind: number = 0;
  // description: string = '';
  // iconWeather: string = '';
  // cities: { city: string }[] = [
  //   { city: 'Kyiv'},
  //   { city: 'Lviv'},
  //   { city: 'Donetsk'},
  // ];
  // city: string = 'Kyiv'
  units: string = 'metric';

  cities = ["Kyiv", "Donetsk", "Lviv"];
  city: Observable<string>|undefined;

  selectedOption: string = this.city;

  constructor(private weatherService: WeatherService) {
  }

  weatherData?: WeatherInfo;

  // data$: Observable<WeatherInfo> = [{
  //   "name": "Kyiv"
  // }];

  ngOnInit() {
    // this.weatherService.getWeather(this.city, this.units).subscribe({
    //   next: (res) => {
    //     this.weatherData = res;
    //     this.temperature = this.weatherData.main.temp;
    //     // this.temp_feel = this.myWeather.main.feels_like;
    //     // this.humidity = this.myWeather.main.humidity;
    //     // this.wind = this.myWeather.wind.speed;
    //     // this.description = this.myWeather.weather[0].description;
    //     // this.iconWeather = 'https://openweathermap.org/img/wn/' + this.myWeather.weather[0].icon + '@2x.png'
    //   },
    //   error: (error) => console.log(error.message),
    //   complete: () => console.log('API call completed')
    // })
  }

  onSelectChange():void {
    this.data$ = this.weatherService.getWeather(this.selectedOption, this.units);
  }

}
