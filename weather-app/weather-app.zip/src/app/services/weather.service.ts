import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { WeatherInfo } from "../interfaces/weather";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  constructor(private http: HttpClient) {
  }

  // selectedOption: string = 'default';
  // data$: Observable<any>;

  getWeather(city: string, units: string): Observable<WeatherInfo> {
    const url = 'https://api.openweathermap.org/data/2.5/weather?q=' + city +
      '&appid=903d99fa7fc59eb260f520af7b82036d&units=' + units;
    return this.http.get<WeatherInfo>(url);
  }

  // onSelectChange(): void {
  //   this.data$ = this.getWeather(this.selectedOption);
  // }
}
